var texts = {
    "logo": "SOFTWARE STUDIO",
    "menu_home": "Home",
    "menu_services": "Services",
    "menu_company": "Company",
    "menu_careers": "Careers",
    "menu_contact": "Contact Us",
    "header": "European Mobile Application Development Company",
    "category1": "Business Apps",
    "category2": "Entertainment Apps",
    "category3": "Gaming Apps",
    "p1": "Mobile phone application development for businesses from all arount the world across all major smartphone platforms.",
    "p2": "We can take your business mobile with fast & affordable mobile application development, which could potentially deliver your products or services to millions of people.",
    "p3_1": "Our first class mobile application development team will",
    "p3_2": "design and build an application specifically for your company!",
    "p4": "We can provide you with any mobile application (for iPhone, Android or Windows) be it a game, simple advertisement, educational or business application of any level of complexity.",
    "p5": "Smartphone's are everywhere and many of your customers will be using them, isn't it time you considered app development and took your business mobile?",
    "p6": "Now is the time to take your company mobile through a dedicated & branded application. Remember, while you are thinking about it, your competitors are doing it - so don't delay - take action today.",
    "call1": "If you're considering mobile application development, then call one of our consultants now on",
    "phone_prefix": "+371",
    "phone_number": "2 9153367",
    "call2": "to see how you could get your business mobile",
    "copyright": "Copyright © 2012 DOT 44. All rights Reserved.",

    "form": {
        "title": "Request for quote",
        "name": "Your Name",
        "email": "E-mail",
        "message": "Message",
        "send": "SEND",
        "send_again": "SEND AGAIN",
        "send_another": "Send another message",
        "thanks": "Thank you!",
        "success_description": "Description text goes here, please pay attention to line-height and paragraph paddings."
    },

    "quote": {
        "title": "Client testimonials",
        "name": "Jeff Richards",
        "company": "YellowPages Company",
        "body": "We were and still are on a mission to change the world as we know it. Six years and lots of blood, sweat, and tears later, we know how.",
        "learn_more": "Lear More"
    }
};